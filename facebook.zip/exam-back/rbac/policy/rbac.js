const RBAC = require('easy-rbac')
const opts = require('./index')

const rbac = RBAC.create(opts)


module.exports=rbac