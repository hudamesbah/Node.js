
const { UPDATE_PROFILLE ,ADD_POST} = require("../../moduls/users/endPoints");



module.exports=[UPDATE_PROFILLE],[ADD_POST]