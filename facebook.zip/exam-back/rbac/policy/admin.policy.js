// const { DELET_USERS } = require("../../moduls/users/endPoints");

const {  CRUD_ADVERTISING, VIEW_ALL_POSTS, BLOCK_USER, REPORT_ACTION } = require("../../moduls/users/endPoints");



module.exports=[ CRUD_ADVERTISING],[VIEW_ALL_POSTS],[BLOCK_USER],
[REPORT_ACTION]