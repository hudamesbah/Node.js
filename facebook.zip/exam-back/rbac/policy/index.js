 const roles = require('../../enum/roles')
 const adminPolicy=require('./admin.policy')
 const superAdminPolicy = require('./superAdmin.policy')
 const userPolicy=require('./user.policy')

const opts={
    [roles.ADMIN]:{
      can:  adminPolicy,
    },
    [roles.SUPERADMIN]:{
        can :superAdminPolicy
    },
    [roles.USER]:{
      can:  userPolicy,
    }
}


module.exports=opts