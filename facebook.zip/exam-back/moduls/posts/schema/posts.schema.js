
const mongoose = require('mongoose');
//const bcrypt = require('bcrypt');

const postsSchema = new mongoose.Schema({
content :{type:String},
title:{type:String },
desc:{type:String},
createdBy: { type:mongoose.Types.ObjectId, ref: 'User' },
advertising:{type:Boolean, default:false},
postImage:{type:String},

     isdeactivated:{type:Boolean, default:false},
     postID:{type:mongoose.Schema.Types.ObjectId },
     reportComment:{type:mongoose.Schema.Types.String },
     
     userID:{type:mongoose.Schema.Types.ObjectId },
     block:{type:Boolean, default:false}
},{
    timestamps:true

}
)




module.exports=postsSchema