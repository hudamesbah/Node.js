//const { object } = require('joi')
const Joi = require('joi')
module.exports={
    CreateoPostSchema:{
        body:Joi.object().required().keys({
            title:Joi.string().required(),
            desc:Joi.string().required(),
            createdBy:Joi.string()
        })
    },
    deletPostSchema:{
        params:Joi.object().required().keys({
            id:Joi.string(),
        })
    },
    editPostSchema:{
        params:Joi.object().required().keys({
            id:Joi.string(),
        }),
        body:Joi.object().required().keys({
            title:Joi.string().optional(),
            desc:Joi.string().optional(),
        })

    },
    AdSchema:{
        body:Joi.object().required().keys({
            isdeactivated:Joi.boolean().optional(),
            title:Joi.string().optional(),
            desc:Joi.string().optional(),

        })
    },
    AdSchema:{
    body:Joi.object().required().keys({
        isdeactivated:Joi.boolean().optional(),
        title:Joi.string().optional(),
        desc:Joi.string().optional(),

    })
},
newFeedSchema:{
    body:Joi.object().required().keys({
        isdeactivated:Joi.boolean().optional() ,
        block:Joi.boolean().optional() 
    })

},
userReportSchema:{
    
    body:Joi.object().required().keys({
        userID:Joi.string().optional(),

        postID:Joi.string().optional(),
        reportComment:Joi.string().optional()

    })
}
}
