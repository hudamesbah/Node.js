const validationRequest=require('../../../common/validationRequest');
const {  ctreat_post, deletPosts, get_profile_post, edit_posts, deactivate_account, news_feed, Ad, reportByUser, getAllPosts, addPost, } = require('../controller/posts.controller');
const { CreateoPostSchema, deletPostSchema, editPostSchema, newfeedSchema, AdSchema, newFeedSchema, userReportSchema} = require('../joi/postsVakidation');
const isAuthorized =require('../../../common/isAuthorized')
const router = require('express').Router()
const multer =require("multer");
const { ADD_POST } = require('../../users/endPoints');
const uploads = multer({
    dest:"uploads/"
})
router.post('/creatPost',validationRequest(CreateoPostSchema),ctreat_post)
//router.delete('./deletePosts',deletPosts)
router.post('/getAllPosts',isAuthorized(ADD_POST),uploads.single('postImage'),getAllPosts)
router.post('/uploads',addPost)
router.put('/edit/:id',validationRequest(editPostSchema),edit_posts)
router.delete('/deletPost/:id',validationRequest(deletPostSchema),deletPosts)
router.patch('/deactivate/:id',deactivate_account)

router.post('/Ad',validationRequest(AdSchema),Ad)
router.get('/profilePost/:id',get_profile_post)
router.post('/report/:id',validationRequest(userReportSchema),reportByUser)

router.post('/newsFeed',validationRequest(newFeedSchema),news_feed)
module.exports=router