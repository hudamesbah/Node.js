const mongoose = require('mongoose');
const postsSchema = require('../../posts/schema/posts.schema');
//const userSchema = require('../schema/user.Schema');
const postsModel =mongoose.model("post",postsSchema)


module.exports=postsModel