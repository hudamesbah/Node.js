//const postModel =require('../model/posts.model')
const{StatusCodes}=require('http-status-codes');
const postsModel = require('../model/posts.model');






const reportByUser = async(req,res)=>{
  const{id}= req.params
   let {userID , postID ,  reportComment} = req.body
  try {
    const report = await postsModel.findOneAndUpdate({userID:id})
    
    // console.log("deleted sucess");
    res.status(StatusCodes.ACCEPTED).json({message:`${reportComment}.....report sucess`,data:report})
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"fail"})

      
  }
   

}






const deactivate_account= async(req,res)=>{
  try {
    const{id}= req.params
    const deactive = await postsModel.findByIdAndUpdate({_id:id},{isdeactivated:true})
    res.status(StatusCodes.OK).json({message:"acount not active", deactive})
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"fail"})

    
  }
 

}



const edit_posts = async(req,res)=>{


  let {id }= req.params ;
  let{title ,desc}= req.body;
  try {
    const edit = await postsModel.updateMany({_id:id},{title:title}||{desc:desc})

    res.status(StatusCodes.ACCEPTED).json({message:"edit sucess",edit})  
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"fail"})
  }
  
  
  
}
const news_feed= async(req,res)=>{
  try {
    console.log(req.user);
     const {isdeactivated,block}= req.body
     if(!isdeactivated){
       if(!block){
        const User= await userModel.find({}).select("-password")
      
        console.log("sucess");
        res.status(StatusCodes.OK).json({message:"sucess",data:User})
       
      }
     
      
     }else{
       res.status(StatusCodes.UNAUTHORIZED).json({message:"UNAUTHORIZED"})
    }
    
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"error",error})
    
  }
     
  
}





const get_profile_post= async(req,res)=>{
  try {
    let {id} = req.params
    const posts = await postsModel.findById({_id:id})
    res.status(StatusCodes.OK).json({message:"see posts",posts})
    
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"error",error})
    
  }
}  
  


  const Ad= async(req,res)=>{
    try {
        
        const {title , desc,isdeactivated }=req.body;
        const posts = await postsModel.insertMany({title , desc,isdeactivated });
        res.status(StatusCodes.CREATED).json({message:"view Ad",posts})
        
    } catch (error) {
        res.status(StatusCodes.BAD_REQUEST).json({message:"error",error})
        
    }
}


const ctreat_post= async(req,res)=>{
    try {
        
        const {title , desc , createdBy}=req.body;
        //console.log(req.file);
        const posts = await postsModel.insertMany({title , desc , createdBy});
        await posts.save()
        res.status(StatusCodes.CREATED).json({message:"created sucess",posts})
        
    } catch (error) {
        res.status(StatusCodes.BAD_REQUEST).json({message:"error",error})
        
    }
}

const addPost =async(req,res)=>{
  const {title , content , createdBy,postImage}=req.body;
console.log(req.file);
const newPost=new postsModel({
  title,
  content,
  createdBy,
  postImage:req.file.path
});
await newPost.save()
res.json({message:"post created",newPost})
}




const deletPosts = async(req,res)=>{
      let {id} = req.params
      try {
        await postsModel.deleteOne({_id:id})
        console.log("deleted sucess");
        res.status(StatusCodes.OK).json({message:"deleted sucess",data:User})
      } catch (error) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"deleted fail"})
          
      }
       
    
    }




    const getAllPosts= async(req,res)=>{
let {page,size}=req.params;
if(!page){
  page=1;
}
if(!size){
  size=10;
}
const limit = parseInt(size)
const skip =(page-1)*size;
const all = await postsModel.count();
const totalPosts = Math.ceil(all/limit)
const posts = await postsModel.find({}).populate("createdBy").limit(limit).skip(skip);
res.json({message:"all posts",limit,skip,totalPosts,size,data:posts})
    }


module.exports={
  ctreat_post,
  deletPosts,
  get_profile_post,
  edit_posts,
  deactivate_account,
  news_feed,
  Ad,
  reportByUser,
  getAllPosts,
  addPost
}


 