const mongoose = require('mongoose');
const userSchema = require('../schema/user.Schema');
//const userSchema = require('../schema/user.Schema');
const userModel =mongoose.model('User',userSchema)


module.exports=userModel