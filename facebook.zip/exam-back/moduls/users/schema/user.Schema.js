//const { boolean } = require('joi');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({

     username:{type:String },
     email:{type:String},
     password:{type:String},
     cPassword:{type:String},
     oldpassword:{type:String},
    
     newPassword:{type:String},
     cnewPassword:{type:String},
     phone:{type:Number},
     location:{type:String},
     role:{type:String,default:'user'},
    
},{
    timestamps:true
    

}
)
userSchema.pre('save', async function(next){
   // this.oldpassword= await bcrypt.hash(this.oldpassword,7)
    this.password= await bcrypt.hash(this.password,7)
    this.cPassword= await bcrypt.hash(this.cPassword,7)
   // this.newPassword= await bcrypt.hash(this.newPassword,7)
   // this.cnewPassword= await bcrypt.hash(this.cnewPassword,7)

    

    next();

})

// userSchema.post('save', async function(next){
//     this.oldpassword= await bcrypt.hash(this.oldpassword,7)
//     //  this.password= await bcrypt.hash(this.password,7)
//     //  this.cPassword= await bcrypt.hash(this.cPassword,7)
//     this.newPassword= await bcrypt.hash(this.newPassword,7)
//     this.cnewPassword= await bcrypt.hash(this.cnewPassword,7)
 
     
 
//      next();
 
//  })
// userSchema.pre('find', function() {
//     console.log(`befor...${new Date()}`); 
//     // true
//    // this.start = Date.now();
//   });
//   userSchema.post('find', function() {
//     console.log(`after...${new Date()}`); 
//     // true
//    // this.start = Date.now();
//   });

module.exports=userSchema