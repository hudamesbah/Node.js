//const Joi = require('joi')
//const joi =require('joi')

//const { json } = require('express')
const Joi = require('joi')
module.exports={
    signUpSchema:{
        body:Joi.object().required().keys({
            username:Joi.string().required().messages({
                "username.empty":"sorry....name is not valid"
            }),
            email:Joi.string().required().email().messages({
                //.messages({
                    "string.email":"sorry...email is vaild"
            })

            ,
            password:Joi.string().required(),
            cPassword:Joi.string().equal(Joi.ref('password')).required().messages({
                "string.cPassword":"soory .....enter password again"
            }),
            // cPassword: Joi.any().equal(Joi.ref('password')).required()
            // .label('Confirm password')
            // .options({ messages: { 'any.only': '{{#label}} does not match'} })
            //  }),
        phone:Joi.number().required().messages({
            "number.phone":"sorry....phone is valid"
        }),
        location:Joi.string().required(),
        role:Joi.string()

        })
},
signInSchema:{
    body:Joi.object().required().keys({
        email:Joi.string().required().email(),
            password:Joi.string().required()

    })
},
UpdateProfileSchema:{
    params:Joi.object().required().keys({
        id:Joi.string(),
    }),
    body:Joi.object().required().keys({
        username:Joi.string().optional(),
        email:Joi.string().required().email(),
        password:Joi.string().optional(),
        //cPassword:Joi.string().equal(Joi.ref('password')).required(),
        phone:Joi.number().optional(),
        location:Joi.string().optional(),
        


        
    })
    
    
} ,
updatePasswordSchema:{
    params:Joi.object().required().keys({
        id:Joi.string().required()
    }),
    body:Joi.object().required().keys({
       // Password:Joi.string().required(),
        oldpassword:Joi.string().equal(Joi.ref('Password')).optional(),
        newPassword:Joi.string().trim().required(),
        cnewPassword:Joi.string().equal(Joi.ref('newPassword')).required()
        
    })
    
}
}


// module.exports={
//     addUserSchema:{
//         body:Joi.object().required().keys({
//             name:Joi.string().required().messages({
//                 "name.empty":"sorry...name is not valid"
//             }),
//             email:Joi.string().required().email().messages({
//                 "string.email":"sorry...email is vaild"
//             }),
//             password:Joi.string().required(),
//             role:Joi.string(),
//         })
//     },
//     signInSchema:{
//         body:Joi.object().required().keys({
//             email:Joi.string().required().email(),
//             password:Joi.string().required()
//         })
//     }
// }