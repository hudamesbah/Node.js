
 const validationRequest=require('../../../common/validationRequest');

const { sign_up, sign_in, Update_profile, Update_Password } = require('../controller/user.controller')
const {signUpSchema, signInSchema, UpdateProfileSchema, updatePasswordSchema} = require('../joi/uservalidation.joi');
const router = require('express').Router()
//const isAuthorized = require('../../../common/isAuthorized');






router.post('/signUp',validationRequest(signUpSchema),sign_up);
router.post('/signIn',validationRequest(signInSchema),sign_in);
router.put('/Update_Profile/:id',validationRequest(UpdateProfileSchema),Update_profile)
router.put('/Update_Password/:id',validationRequest(updatePasswordSchema),Update_Password)


module.exports=router