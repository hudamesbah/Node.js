const mongoose = require('mongoose');

const connection = ()=>{
    return   mongoose.connect(process.env.CONNECTION_STRING)
}

module.exports=connection