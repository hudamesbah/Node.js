//const userModel = require("../model/user.model");

const userModel =require('../model/user.model')
const{StatusCodes}=require('http-status-codes')
const bcrypt = require('bcrypt');
const jwt =require('jsonwebtoken')
const nodemailer = require("nodemailer");

let transporter = nodemailer.createTransport({
  service: "gmail",
  
  auth: {
    //put sender email you want
    user: 'testAccount.user', // generated ethereal user
    pass: 'testAccount.pass', // generated ethereal password
  },
});

const sign_up= async(req,res)=>{
  let {username , email , password , cPassword , phone , location ,  role}= req.body;
  try {
    const newUser =await userModel.findOne({email})
    if(newUser){
      res.status(StatusCodes.BAD_REQUEST).json({message:"email is already exist....please try again!!"})
    }else{
      const User = new userModel({username , email , password , cPassword , phone , location})
      await User.save()
      let info = await transporter.sendMail({
        from: '"node  👻" <foo@example.com>', // sender address
        to: `${email}`, // list of receivers
        subject: "Hello ✔", // Subject line
        text: "Hello world?", // plain text body
        html: "<b>Hello world?</b>", // html body
      });
      res.status(StatusCodes.CREATED).json({message:"created sucess "})
    }
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"error",error})
    
  }
  
}







const sign_in = async(req,res)=>{
  const{email,password}=req.body
  try {
    const user = await userModel.findOne({email})
    if(!user){
      res.status(StatusCodes.BAD_REQUEST).json({message:"email is not valid"})
    }else{
      const match = await bcrypt.compare(password,user.password);
      if(match){
        var token = jwt.sign({ _id:user._id,role: user.role }, 'exam')
        res.status(StatusCodes.OK).json({
          token,
           user:{
            id:user._id,
           name:user.name,
            email:user.email
          }

        })
      }else{
        res.send("error")
          
      }

    }
    
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      message:"sorry..try again plz"
    })
    
  }
}



const Update_profile =async (req,res)=>{
  let {id }= req.params
  let{username,email,password,phone,location,}= req.body
  try {
   //  var token = jwt.sign({ _id:user._id }, 'exam')

    const user = await userModel.findByIdAndUpdate({_id:id},{username:username}||{email:email}||{password:password}||{phone:phone}||{location:location})
    var token = jwt.sign({ _id:user._id }, 'exam')

    res.status(StatusCodes.ACCEPTED).json({message:"update sucess",user,token})
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"something not valid"})


    
  }
}



const Update_Password= async(req,res)=>{
  let{id}= req.params
  let{newPassword,cnewPassword,oldpassword}=req.body
  try {
     
      
    const user = await userModel.updateMany({_id:id},{newPassword:newPassword},{cnewPassword:cnewPassword})
    res.json("update sucess ")
  } catch (error) {
   res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({message:"something not valid"})
  }

}





module.exports={
  sign_up,
  sign_in,
  Update_profile,
  Update_Password,
  
    
}
