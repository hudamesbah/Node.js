const roles = Object.freeze({
    ADMIN:'admin',
   SUPERADMIN :'superAdmin',
    USER:'user'
})
module.exports=roles