const jwt =require('jsonwebtoken');
//const roles = require('../enum/roles');

const rbac = require('../rbac/policy/rbac');
module.exports=(endPoint)=>{
    return async (req,res,next)=>{
        const token =req.header.authorization.split(' ')[1];
        var decoded = jwt.verify(token, 'exam');
        const isAllaw =await rbac.can(decoded.role,endPoint)
        console.log(isAllaw);
        // req.user=decoded
     next()
    }

}