const { StatusCodes } = require('http-status-codes')

module.exports = schema => {
  return (req, res, next) => {
    const validationArr = []
    ;[('headers', 'params', 'query', 'body')].forEach(key => {
      if (schema[key]) {
        const Validation = schema[key].validate(req[key])
        if (Validation.error) {
          validationArr.push(
            Validation.error.details[0].message
          )
        }
      }
    });
    if (validationArr.length) {
      return res
        .status(StatusCodes.BAD_REQUEST)
        .json({ message: validationArr.join() })
    }
    next();
  }
}