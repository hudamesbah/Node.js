const express = require('express')
const connection = require('./moduls/users/configration/config')
const app = express()

require('dotenv').config()
app.use(express.json())
console.log("process:",process.env.PORT);
const port = process.env.PORT
connection()

const userRouter = require('./moduls/users/router/user.router')
const postsRouter = require('./moduls/posts/router/postes.router')
//const connectionPOST = require('./moduls/posts/CONFIGRATION/CONFIG.JS')
app.use(userRouter , postsRouter)
app.get('/', (req, res) => res.send('Hello World!'))
app.listen(port, () => console.log(`Example app listening on port ${port}
}`))